import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
import Logo from './Logo';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errors, setErrors] = useState<string[]>([]);

  const handleSubscribe = async (e: FormEvent) => {
    e.preventDefault();
    setErrors([]);
    setStatus('loading');
    try {
      const res = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const result = await res.json();
      if (res.ok) {
        setStatus('success');
        setEmail('');
      } else {
        setStatus('error');
        if (result.errors) setErrors(result.errors);
      }
    } catch (err) {
      setStatus('error');
      setErrors(['Network error. Please try again.']);
    }
  };

  return (
    <footer className="bg-primary text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Info */}
          <div className="space-y-6">
            <Link to="/" className="inline-block">
              <Logo variant="light" size="lg" />
            </Link>
            <p className="text-white/60 text-sm leading-relaxed max-w-xs">
              Dedicated to publishing meaningful literature that inspires knowledge, creativity, and intellectual growth since its inception.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white/60 hover:text-secondary transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white/60 hover:text-secondary transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white/60 hover:text-secondary transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white/60 hover:text-secondary transition-colors" aria-label="LinkedIn">
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col items-center">
            <h3 className="text-lg font-serif font-medium mb-6 text-secondary italic">Quick Links</h3>
            <ul className="space-y-4 text-center">
              {['Home', 'Books', 'Authors', 'About Us', 'Contact', 'Admin'].map((link) => (
                <li key={link}>
                  <Link 
                    to={
                      link === 'About Us' ? '/about' : 
                      `/${link.toLowerCase().replace(' ', '-')}`
                    } 
                    className="text-white/60 hover:text-secondary text-sm transition-all hover:tracking-widest flex items-center justify-center group"
                  >
                    <span className="w-0 group-hover:w-2 h-[1px] bg-secondary mr-0 group-hover:mr-2 transition-all opacity-0 group-hover:opacity-100" />
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-lg font-serif font-medium mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3 text-sm text-white/60">
                <MapPin size={18} className="text-secondary shrink-0 mt-0.5" />
                <span>123 Literature Lane, Cultural Square, New Delhi, India</span>
              </li>
              <li className="flex items-center space-x-3 text-sm text-white/60">
                <Phone size={18} className="text-secondary shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center space-x-3 text-sm text-white/60">
                <Mail size={18} className="text-secondary shrink-0" />
                <span>contact@deepamkesari.com</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-serif font-medium mb-6">Newsletter</h3>
            <p className="text-white/60 text-sm mb-6">
              Subscribe to stay updated on our latest releases and author events.
            </p>
            {status === 'success' ? (
              <div className="bg-white/10 p-4 rounded-md text-sm text-secondary font-medium text-center">
                Thank you for subscribing!
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col space-y-3">
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address" 
                  className="bg-white/5 border border-white/10 rounded-md py-3 px-4 text-sm focus:outline-none focus:border-secondary transition-colors"
                />
                <button 
                  type="submit"
                  disabled={status === 'loading'}
                  className="bg-secondary text-primary font-medium text-sm py-3 px-6 rounded-md hover:bg-secondary/90 transition-colors disabled:opacity-50"
                >
                  {status === 'loading' ? 'Subscribing...' : 'Subscribe'}
                </button>
                {status === 'error' && (
                  <div className="space-y-1">
                    {errors.length > 0 ? (
                      errors.map((err, i) => <p key={i} className="text-red-400 text-[10px]">{err}</p>)
                    ) : (
                      <p className="text-red-400 text-[10px]">Something went wrong. Please try again.</p>
                    )}
                  </div>
                )}
              </form>
            )}
          </div>
        </div>

        <div className="pt-10 border-t border-white/10 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-white/40 text-xs text-center md:text-left">
            © {currentYear} Deepam Kesari Publishing House. All rights reserved.
          </p>
          <div className="flex space-x-8 text-xs text-white/40">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
