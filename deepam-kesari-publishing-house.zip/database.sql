-- Database Structure for Deepam Kesari Publishing House

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for authors
-- ----------------------------
DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `photo` varchar(1024) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `role` varchar(100) DEFAULT 'Author',
  `academic_pedigree` varchar(500) DEFAULT NULL,
  `creative_focus` varchar(500) DEFAULT NULL,
  `performing_arts` varchar(500) DEFAULT NULL,
  `literary_vision` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of authors
-- ----------------------------
INSERT INTO `authors` (`id`, `name`, `photo`, `bio`, `role`, `academic_pedigree`, `creative_focus`, `performing_arts`, `literary_vision`) VALUES 
(1, 'Dr. Aranya Sharma', 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=400', 'Dr. Aranya Sharma is a renowned academic and philosopher who has dedicated over 30 years to researching ancient Indian literature. Her works are praised for their scholarly depth and accessibility.', 'Author', NULL, NULL, NULL, NULL),
(2, 'Vikram Sethi', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400', 'Vikram Sethi is a polyglot and master translator known for bringing the nuances of Sanskrit poetry into modern languages without losing their original soul.', 'Translator', NULL, NULL, NULL, NULL),
(3, 'Meera Iyer', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=400', 'Meera Iyer writes contemporary fiction and poetry that explores themes of identity, culture, and transformation in modern India.', 'Author', NULL, NULL, NULL, NULL),
(4, 'Deep Patel', '/input_file_2.png', 'Rooted in values and inspired by life itself, Deep Patel is a writer and publisher at Deepam Kesari Publishing House. He writes with the intention of preserving culture, expressing genuine human emotions, and encouraging positive change through meaningful literature.', 'Author', 'Master\'s degree in Science (M.Sc.) with specialization in Organic Chemistry', 'Gujarati Literature & Culture', 'Navodit Artist in Lokdayra', 'Writing is not merely a profession but a responsibility—to reflect truth, inspire courage, and create stories that leave a thoughtful and lasting impact on readers across generations.');

-- ----------------------------
-- Table structure for books
-- ----------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `cover_image` varchar(1024) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `amazon_link` varchar(1024) DEFAULT NULL,
  `whatsapp_link` varchar(1024) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `language` varchar(100) DEFAULT NULL,
  `featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_author` (`author_id`),
  CONSTRAINT `fk_author` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of books
-- ----------------------------
INSERT INTO `books` (`id`, `title`, `author_id`, `cover_image`, `description`, `isbn`, `amazon_link`, `whatsapp_link`, `category`, `language`, `featured`) VALUES 
(1, 'The Golden Path', 1, 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=800', 'The Golden Path is a profound exploration into the evolution of spiritual philosophy in ancient India. Dr. Aranya Sharma meticulously traces the threads of thought from the early Vedic period through the Upanishadic breakthroughs and the eventual synthesis in the Bhagavad Gita.\n\nIn this work, the author challenges contemporary interpretations and offers a fresh perspective based on direct readings of primary sources.', '978-1234567890', 'https://amazon.com', 'https://wa.me/919876543210', 'Philosophy', 'Hindi', 1),
(2, 'Echoes of the Past', 2, 'https://images.unsplash.com/photo-1532012197267-da84d127e766?auto=format&fit=crop&q=80&w=800', 'An exploration of collective memory and historical narratives. Discover how our ancestors shaped the world we live in today through their struggles, triumphs, and the stories they left behind.', '978-0987654321', 'https://amazon.com', 'https://wa.me/919876543210', 'History', 'English', 1),
(3, 'Modern Wisdom', 3, 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=800', 'Practical advice for navigating the complexities of the 21st century with grace and intelligence. Meera Iyer compiles modern philosophical approaches to mental clarity and ethical living.', '978-5432109876', 'https://amazon.com', 'https://wa.me/919876543210', 'Academic', 'English', 1),
(4, 'Infinite Skies', 1, 'https://images.unsplash.com/photo-1543004471-2406836eb8a4?auto=format&fit=crop&q=80&w=800', 'A collection of poetry that captures the ethereal beauty of the universe and our place within it. These verses delve into the silence between thoughts and the majesty of nature.', '978-1122334455', 'https://amazon.com', 'https://wa.me/919876543210', 'Poetry', 'Hindi', 1),
(5, 'The Silent Script', 3, 'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=800', 'A gripping novel that explores the hidden lives of individuals tied together by a mysterious manuscript found in a remote Himalayan monastery.', '978-9988776655', 'https://amazon.com', 'https://wa.me/919876543210', 'Fiction', 'English', 0),
(6, 'રસ્તો કરી જવાના', 4, '/input_file_5.png', 'રસ્તો કરી જવાના (Rasto Kari Javan) is a collection of soul-stirring Gujarati poems and prose that resonate with the essence of life, resilience, and the human spirit. Deep Patel brings a modern yet deeply rooted perspective to classical Gujarati literary forms.', '978-8877665544', 'https://amazon.com', 'https://wa.me/919876543210', 'Poetry', 'Gujarati', 1);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for reviews
-- ----------------------------
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `rating` int(1) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_review_book` (`book_id`),
  CONSTRAINT `fk_review_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of reviews
-- ----------------------------
INSERT INTO `reviews` (`id`, `book_id`, `user_name`, `rating`, `comment`) VALUES 
(1, 1, 'Amit Sharma', 5, 'Truly a masterpiece. Changed my perspective on ancient philosophy.'),
(2, 6, 'Rahul Patel', 5, 'Very inspiring collection. Must read for every literature lover.'),
(3, 2, 'Sneha Gupta', 4, 'Excellent historical context. The translation is very smooth.');

-- ----------------------------
-- Table structure for contact_requests
-- ----------------------------
DROP TABLE IF EXISTS `contact_requests`;
CREATE TABLE `contact_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for subscribers
-- ----------------------------
DROP TABLE IF EXISTS `subscribers`;
CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `subscribed_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for manuscripts
-- ----------------------------
DROP TABLE IF EXISTS `manuscripts`;
CREATE TABLE `manuscripts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `genre` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
