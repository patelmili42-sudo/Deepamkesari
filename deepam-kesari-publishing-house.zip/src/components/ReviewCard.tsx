import React from 'react';
import { motion } from 'motion/react';
import { Review } from '../types';
import { Quote, Star } from 'lucide-react';

interface ReviewCardProps {
  review: Review;
  index?: number;
  key?: string | number;
}

export default function ReviewCard({ review, index = 0 }: ReviewCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      className="bg-white/50 backdrop-blur-sm p-8 rounded-2xl border border-primary/5 hover:border-secondary/20 hover:shadow-xl hover:shadow-primary/5 transition-all group flex flex-col h-full"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex space-x-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              size={12}
              className={i < review.rating ? "fill-secondary text-secondary" : "text-primary/10"}
            />
          ))}
        </div>
        <Quote size={20} className="text-secondary/10 group-hover:text-secondary/20 transition-colors" />
      </div>
      
      <p className="text-primary/80 text-base leading-relaxed italic mb-8 grow font-light relative">
        <span className="relative z-10">{review.comment}</span>
      </p>
      
      <div className="flex items-center space-x-4">
        <div className="relative">
          <div className="absolute -inset-1 bg-secondary/20 rounded-full blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
          <div className="relative w-12 h-12 rounded-full overflow-hidden bg-bg border-2 border-white flex items-center justify-center text-secondary font-bold text-lg shadow-sm">
            {review.userName.charAt(0)}
          </div>
        </div>
        <div>
          <h4 className="text-sm font-serif font-bold text-primary group-hover:text-secondary transition-colors">
            {review.userName}
          </h4>
          <div className="flex items-center space-x-2">
            <span className="w-1 h-1 bg-secondary rounded-full" />
            <p className="text-[10px] uppercase tracking-[0.2em] text-primary/40 font-bold">
              Reader
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
