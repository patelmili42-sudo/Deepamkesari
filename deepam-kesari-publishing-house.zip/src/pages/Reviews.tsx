import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import ReviewCard from '../components/ReviewCard';
import { Review } from '../types';
import { Star, MessageSquare } from 'lucide-react';

export default function Reviews() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAllReviews = async () => {
      try {
        const res = await fetch('/api/books');
        const books = await res.json();
        
        // Fetch reviews for each book and flatten
        const reviewsPromises = books.map((book: any) => fetch(`/api/reviews/${book.id}`).then(r => r.json()));
        const allReviewsArrays = await Promise.all(reviewsPromises);
        setReviews(allReviewsArrays.flat().sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      } catch (err) {
        console.error('Failed to fetch reviews', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAllReviews();
  }, []);

  return (
    <div className="bg-bg min-h-screen py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-20 text-center">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className="h-px bg-secondary w-12" />
            <Star className="text-secondary fill-secondary" size={24} />
            <div className="h-px bg-secondary w-12" />
          </div>
          <h2 className="text-secondary text-[10px] uppercase tracking-[0.3em] font-bold mb-4">Voice of Readers</h2>
          <h1 className="text-4xl md:text-6xl font-serif text-primary italic">Community Feedback</h1>
          <p className="mt-8 text-primary/60 max-w-2xl mx-auto font-light leading-relaxed">
            We are humbled by the support and feedback from our global community of readers and scholars.
          </p>
        </header>

        {loading ? (
          <div className="text-center py-20 font-serif italic text-primary/40">Loading reviews...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reviews.map((review, i) => (
              <ReviewCard key={review.id} review={review} index={i} />
            ))}
          </div>
        )}

        <section className="mt-32 max-w-4xl mx-auto bg-primary p-12 md:p-20 rounded-[3rem] shadow-2xl text-center border border-white/10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl -mr-32 -mt-32 group-hover:bg-secondary/20 transition-colors" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl -ml-32 -mb-32 group-hover:bg-secondary/20 transition-colors" />
          
          <div className="relative z-10">
            <MessageSquare className="text-secondary mx-auto mb-8 opacity-80" size={48} />
            <h3 className="text-3xl md:text-5xl font-serif text-white mb-6 italic">Join the Dialogue</h3>
            <p className="text-white/60 mb-10 text-lg leading-relaxed font-light max-w-xl mx-auto">
              Your voice is vital to our literary community. Share your thoughts on our latest releases and help others discover meaningful works.
            </p>
            <Link 
              to="/books"
              className="inline-block bg-secondary text-primary px-12 py-5 rounded-full font-bold uppercase tracking-[0.2em] text-xs hover:bg-white transition-all shadow-xl shadow-black/20 transform hover:-translate-y-1"
            >
              Explore and Review
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}
