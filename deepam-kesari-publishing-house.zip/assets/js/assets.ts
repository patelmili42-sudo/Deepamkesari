/**
 * Assets configuration for the project.
 * This file maps the asset paths for easier management.
 */

export const ASSETS = {
  images: {
    hero: '/assets/images/rasto_kari_javan_collage.png',
    logo: '/assets/images/logo.png',
    waterfall: '/assets/images/waterfall_sunset_view.png',
    reading: '/assets/images/man_reading_in_library.png',
    stack: '/assets/images/stacked_books_promotion.png',
    cover: '/assets/images/rasto_kari_javan_cover_art.png',
  },
  css: {
    global: '/assets/css/global.css',
    theme: '/assets/css/theme.css',
  }
};
